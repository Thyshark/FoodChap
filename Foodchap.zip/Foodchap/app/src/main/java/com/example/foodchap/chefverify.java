package com.example.foodchap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class chefverify extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chefverify);
    }
}