package com.example.foodchap;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class DeliveryForgotPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_forgot_password);
    }
}