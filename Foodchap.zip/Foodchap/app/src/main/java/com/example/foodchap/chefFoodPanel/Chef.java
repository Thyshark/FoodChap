package com.example.foodchap.chefFoodPanel;

public class Chef {
    private String Area,  ConfirmPassword, Emailid, Fname, House,  Mobile, Password, Postcode;

    // Press Alt+Insert


    public Chef(String area, String city, String confirmPassword, String emailid, String fname, String house, String lname, String mobile, String password, String postcode, String state) {
        this.Area = area;

        ConfirmPassword = confirmPassword;
        Emailid = emailid;
        Fname = fname;
        House = house;

        Mobile = mobile;
        Password = password;
        Postcode = postcode;

    }
    public Chef() {
    }

    public String getArea() {
        return Area;
    }



    public String getConfirmPassword() {
        return ConfirmPassword;
    }

    public String getEmailid() {
        return Emailid;
    }

    public String getFname() {
        return Fname;
    }

    public String getHouse() {
        return House;
    }



    public String getMobile() {
        return Mobile;
    }

    public String getPassword() {
        return Password;
    }

    public String getPostcode() {
        return Postcode;
    }


}
