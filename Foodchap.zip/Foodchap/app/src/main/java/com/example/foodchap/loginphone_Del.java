package com.example.foodchap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class loginphone_Del extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginphone_del);
    }
}